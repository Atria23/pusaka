<?php
/**
 * Plugin Name: Tutor LMS Quiz Summary Export
 * Description: Menampilkan ringkasan hasil kuis dan detail jawaban dari Tutor LMS dengan tombol salin ke clipboard, pencarian, filter tanggal, ekspor Excel, dan paginasi.
 * Version: 1.8
 */

add_action('admin_menu', function () {
    add_menu_page(
        'Tutor LMS Export',
        'Tutor LMS Export',
        'manage_options',
        'tutor-quiz-summary',
        'render_tutor_quiz_summary_page',
        'dashicons-welcome-learn-more',
        81
    );
});

function render_tutor_quiz_summary_page() {
    global $wpdb;
    $prefix = $wpdb->prefix;

    $attempts_table = "{$prefix}tutor_quiz_attempts";
    $answers_table = "{$prefix}tutor_quiz_attempt_answers";
    $questions_table = "{$prefix}tutor_quiz_questions";
    $users_table = "{$prefix}users";
    $posts_table = "{$prefix}posts";
    $answer_table = "{$prefix}tutor_quiz_question_answers";

    $per_page = 200;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($paged - 1) * $per_page;

    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';

    function get_answer_texts($wpdb, $serialized_answer) {
        $table = $wpdb->prefix . 'tutor_quiz_question_answers';
        $answer_ids = maybe_unserialize($serialized_answer);
        if (!is_array($answer_ids)) $answer_ids = [$answer_ids];
        $answer_ids = array_filter($answer_ids);
        if (empty($answer_ids)) return ['(Kosong)'];

        $placeholders = implode(',', array_fill(0, count($answer_ids), '%d'));
        $query = $wpdb->prepare("SELECT answer_title FROM {$table} WHERE answer_id IN ($placeholders)", $answer_ids);
        $results = $wpdb->get_col($query);
        return !empty($results) ? $results : [$serialized_answer];
    }

    // DETAIL ATTEMPT
    if (isset($_GET['attempt_id'])) {
        $attempt_id = intval($_GET['attempt_id']);

        $info = $wpdb->get_row("
            SELECT u.user_email, quiz.post_title AS quiz_title
            FROM {$attempts_table} a
            LEFT JOIN {$users_table} u ON a.user_id = u.ID
            LEFT JOIN {$posts_table} quiz ON a.quiz_id = quiz.ID
            WHERE a.attempt_id = {$attempt_id}
        ");

        $details = $wpdb->get_results("
            SELECT q.question_title, a.given_answer, a.achieved_mark, a.is_correct
            FROM {$answers_table} a
            LEFT JOIN {$questions_table} q ON a.question_id = q.question_id
            WHERE a.quiz_attempt_id = {$attempt_id}
        ");

        echo "<div class='wrap'><h2>Detail Jawaban Attempt #{$attempt_id}</h2>";
        echo "<p><strong>Quiz:</strong> {$info->quiz_title}<br><strong>User:</strong> {$info->user_email}</p>";
        echo "<form onsubmit='copyTable(event)'><button class='button button-primary'>Salin Tabel</button></form><br>";
        echo "<a href='admin.php?page=tutor-quiz-summary' class='button'>← Kembali</a><br><br>";
        echo "<table class='widefat striped'><thead><tr>
                <th>No</th><th>Pertanyaan</th><th>Jawaban</th><th>Skor</th><th>Status</th>
              </tr></thead><tbody>";
        foreach ($details as $i => $d) {
            $status = $d->is_correct ? '✅ Benar' : '❌ Salah';
            $jawaban = implode(', ', get_answer_texts($wpdb, $d->given_answer));
            echo "<tr>
                    <td>".($i+1)."</td>
                    <td>{$d->question_title}</td>
                    <td>{$jawaban}</td>
                    <td>{$d->achieved_mark}</td>
                    <td>{$status}</td>
                  </tr>";
        }
        echo "</tbody></table></div>";
        echo get_copy_script();
        return;
    }

    // QUERY UTAMA
    $where = [];
    $params = [];

    if (!empty($search)) {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where[] = "(u.display_name LIKE %s OR u.user_email LIKE %s OR quiz.post_title LIKE %s)";
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    if (!empty($start_date)) {
        $where[] = "a.attempt_started_at >= %s";
        $params[] = $start_date . " 00:00:00";
    }

    if (!empty($end_date)) {
        $where[] = "a.attempt_started_at <= %s";
        $params[] = $end_date . " 23:59:59";
    }

    $where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $count_sql = "
        SELECT COUNT(*) FROM {$attempts_table} a
        LEFT JOIN {$users_table} u ON a.user_id = u.ID
        LEFT JOIN {$posts_table} quiz ON a.quiz_id = quiz.ID
        {$where_sql}
    ";
    $total_rows = $wpdb->get_var($wpdb->prepare($count_sql, ...$params));
    $total_pages = ceil($total_rows / $per_page);

    $main_sql = "
        SELECT 
            a.*, u.display_name, u.user_email,
            quiz.post_title AS quiz_title, course.post_title AS course_title
        FROM {$attempts_table} a
        LEFT JOIN {$users_table} u ON a.user_id = u.ID
        LEFT JOIN {$posts_table} quiz ON a.quiz_id = quiz.ID
        LEFT JOIN {$posts_table} course ON a.course_id = course.ID
        {$where_sql}
        ORDER BY a.attempt_started_at DESC
        LIMIT %d OFFSET %d
    ";
    $results = $wpdb->get_results($wpdb->prepare($main_sql, ...array_merge($params, [$per_page, $offset])));

    echo "<div class='wrap'><h2>Tutor LMS Quiz Summary</h2>";

    // FORM PENCARIAN
    echo "<form method='get' style='margin-bottom: 10px; display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap;'>
    <input type='hidden' name='page' value='tutor-quiz-summary'/>
    
    <div>
        <label for='search'>Pencarian:</label><br>
        <input type='text' id='search' name='s' value='" . esc_attr($search) . "' placeholder='Nama, email, atau kuis' style='width: 200px;'/>
    </div>
    
    <div>
        <label for='start_date'>Dari Tanggal:</label><br>
        <input type='date' id='start_date' name='start_date' value='" . esc_attr($start_date) . "'/>
    </div>
    
    <div>
        <label for='end_date'>Sampai Tanggal:</label><br>
        <input type='date' id='end_date' name='end_date' value='" . esc_attr($end_date) . "'/>
    </div>
    
    <div style='margin-top: 18px;'>
        <button class='button'>Filter</button>
    </div>
</form>";


    echo "<form onsubmit='copyTable(event)'><button class='button button-primary'>Salin Tabel</button></form><br>";
    echo "<button class='button' onclick='downloadExcel()'>Download Excel</button><br><br>";

    echo "<table class='widefat striped' id='quiz-table'><thead><tr>
            <th>Quiz Info</th><th>Course</th><th>Question</th><th>Total Marks</th>
            <th>Correct</th><th>Incorrect</th><th>Earned</th><th>Result</th><th>Details</th>
          </tr></thead><tbody>";

    foreach ($results as $row) {
        $date = date('d M Y H:i', strtotime($row->attempt_started_at));
        $quiz_info = "{$row->quiz_title}, {$row->display_name}, {$date}";
        $correct = (int) $row->total_answered_questions;
        $wrong = max(0, (int) $row->total_questions - $correct);
        $earned = (float) $row->earned_marks;
        $percentage = $row->total_marks > 0 ? round(($earned / $row->total_marks) * 100) : 0;
        $result = $percentage >= 50 ? 'Pass' : 'Fail';

        echo "<tr>
                <td>{$quiz_info}</td>
                <td>{$row->course_title}</td>
                <td>{$row->total_questions}</td>
                <td>{$row->total_marks}</td>
                <td>{$correct}</td>
                <td>{$wrong}</td>
                <td>{$earned} ({$percentage}%)</td>
                <td><strong>{$result}</strong></td>
                <td><a href='admin.php?page=tutor-quiz-summary&attempt_id={$row->attempt_id}' class='button'>Detail</a></td>
              </tr>";
    }

    echo "</tbody></table>";

    // PAGINASI
    echo "<div style='margin-top: 20px;'>";
    for ($i = 1; $i <= $total_pages; $i++) {
        $class = ($i === $paged) ? 'button button-primary' : 'button';
        $url = esc_url(add_query_arg([
            'page' => 'tutor-quiz-summary',
            'paged' => $i,
            's' => $search,
            'start_date' => $start_date,
            'end_date' => $end_date
        ]));
        echo "<a href='{$url}' class='{$class}'>{$i}</a> ";
    }
    echo "</div></div>";

    echo get_copy_script();
}

// SCRIPT JS
function get_copy_script() {
    return <<<HTML
<script>
function copyTable(e) {
    e.preventDefault();
    const table = document.querySelector('#quiz-table');
    if (!table) return alert("Tabel tidak ditemukan.");
    let text = '';
    table.querySelectorAll('tr').forEach(row => {
        let cols = Array.from(row.querySelectorAll('th, td')).map(td => td.innerText.trim());
        text += cols.join('\\t') + '\\n';
    });
    navigator.clipboard.writeText(text).then(() => {
        alert('✅ Tabel berhasil disalin. Silakan paste di Excel atau Google Sheets.');
    }).catch(() => {
        alert('❌ Gagal menyalin tabel.');
    });
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
function downloadExcel() {
    const table = document.querySelector('#quiz-table');
    if (!table) return alert("Tabel tidak ditemukan.");
    const wb = XLSX.utils.table_to_book(table, { sheet: "Quiz Summary" });
    XLSX.writeFile(wb, 'tutor_quiz_summary_filtered.xlsx');
}
</script>
HTML;
}
